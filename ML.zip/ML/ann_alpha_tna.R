library(haven)
library(dplyr)
dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/Research_Data/Clean data/crsp_ms_4_1.dta")
ux<-unique(dat$a1)

if(substr(dat1$style[1],1,1)=="L")
{
  if(substr(dat1$style[1], regexpr(" ", dat1$style) + 1, regexpr(" ", dat1$style) + 1)=="G")
  {
    bm<-"lcg"
  }
  if(substr(dat1$style[1], regexpr(" ", dat1$style) + 1, regexpr(" ", dat1$style) + 1)=="B")
  {
    bm<-"lcb"
  }
  else
  {
    bm<-"lcv"
  }
}
if(substr(dat1$style[1],1,1)=="M")
{
  if(substr(dat1$style[1], regexpr(" ", dat1$style) + 1, regexpr(" ", dat1$style) + 1)=="G")
  {
    bm<-"mcg"
  }
  if(substr(dat1$style[1], regexpr(" ", dat1$style) + 1, regexpr(" ", dat1$style) + 1)=="B")
  {
    bm<-"mcb"
  }
  else
  {
    bm<-"mcv"
  }
}
if(substr(dat1$style[1],1,1)=="S")
{
  if(substr(dat1$style[1], regexpr(" ", dat1$style) + 1, regexpr(" ", dat1$style) + 1)=="G")
  {
    bm<-"scg"
  }
  if(substr(dat1$style[1], regexpr(" ", dat1$style) + 1, regexpr(" ", dat1$style) + 1)=="B")
  {
    bm<-"scb"
  }
  else
  {
    bm<-"scv"
  }
}


#cal realized annualized alphas using 36 month rolling estimators
time<-unique(dat$caldt)

dat_f<-data.frame(matrix(nrow=length(ux),ncol=7))
colnames(dat_f)<-c("Fund","lag_12_mon_alpha","lag_12_mon_t_alpha","lag_12_mon_beta1","lag_12_mon_beta2","lag_12_mon_beta3","lag_12_mon_beta4")
dat_f[,1]<-ux

for(i in 1:length(ux))
{
  dat1<-dat[dat$a1==ux[i],]
  dat1$bm<-dat1$MktRF
  dat1$real_alpha_net<-NA
  s<-1
  e<-12
  time<-sort(unique(dat1$caldt))
  if(nrow(dat1)>8)
  {
    while(e<length(time))
    {
      dat2<-dat1[dat1$caldt>=time[s] & dat1$caldt<=time[e],]
      
      reg<-lm(RF_sum_wt_net_ret~bm+SMB+HML+MOM, data = dat2)
      dat_f[i,2]<-summary(reg)$coefficients[1,1]
      dat_f[i,2]<-summary(reg)$coefficients[1,3]
      dat_f[i,4]<-summary(reg)$coefficients[2,1]
      dat_f[i,5]<-summary(reg)$coefficients[3,1]
      dat_f[i,6]<-summary(reg)$coefficients[4,1]
      dat_f[i,7]<-summary(reg)$coefficients[5,1]
      #dat1$real_alpha_net[e+1]<-dat1$RF_sum_wt_net_ret[e+1]-beta1*(dat1$bm[e+1]/100)-beta2*(dat1$SMB[e+1]/100)-beta3*(dat1$HML[e+1]/100)-beta4*(dat1$MOM[e+1]/100)
      s<-s+1
      e<-e+1
    }
  }
  #dat_f<-rbind(dat_f,dat1)
}
write_dta(dat_f,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/lag_12_monthly.dta")


#cal yearly one year lag ann t-alpha and ann alpha
ux<-unique(dat$a1)

alpha<-data.frame(matrix(nrow=length(ux),ncol=33))
alpha[,1]<-ux
t_alpha<-data.frame(matrix(nrow=length(ux),ncol=33))
t_alpha[,1]<-ux
R2<-data.frame(matrix(nrow=length(ux),ncol=33))
R2[,1]<-ux

beta1<-data.frame(matrix(nrow=length(ux),ncol=33))
beta1[,1]<-ux
beta2<-data.frame(matrix(nrow=length(ux),ncol=33))
beta2[,1]<-ux
beta3<-data.frame(matrix(nrow=length(ux),ncol=33))
beta3[,1]<-ux
beta4<-data.frame(matrix(nrow=length(ux),ncol=33))
beta4[,1]<-ux

y<-unique(year(dat$caldt))

for (i in 1:length(y))
{
  dat1<-dat[dat$y==y[i],]
  u1<-unique(dat1$a1)
  
  for (f in 1:length(u1))
  {
    dat2<-dat1[dat1$a1==u1[f],]
    if(nrow(dat2)<8)
    {
      next
    }
    bm<-"MktRF"
    dat2$bm<-dat2[[bm]]
    reg<-lm(RF_sum_wt_net_ret~ bm+SMB+HML+MOM,data=dat2)
    alpha[match(u1[f],alpha$X1),(i+1)]<-summary(reg)$coefficients[1,1]
    t_alpha[match(u1[f],t_alpha$X1),(i+1)]<-summary(reg)$coefficients[1,3]
    beta1[match(u1[f],beta1$X1),(i+1)]<-summary(reg)$coefficients[2,1]
    beta2[match(u1[f],beta2$X1),(i+1)]<-summary(reg)$coefficients[3,1]
    beta3[match(u1[f],beta2$X1),(i+1)]<-summary(reg)$coefficients[4,1]
    beta4[match(u1[f],beta4$X1),(i+1)]<-summary(reg)$coefficients[5,1]
    R2[match(u1[f],R2$X1),(i+1)]<-summary(reg)$r.squared
    }
  
}

y<-as.character(y)
a<-array(dim=33)
a[1]<-"Fund"
for (b in 2:33)
{
  a[b]<-paste0("y",a[b])
}

colnames(alpha)<-a
colnames(t_alpha)<-a
colnames(beta1)<-a
colnames(beta2)<-a
colnames(beta3)<-a
colnames(beta4)<-a
colnames(R2)<-a

write_dta(alpha,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/1_yr_lag_gross_alpha.dta")
write_dta(t_alpha,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/1_yr_lag_gross_t_alpha.dta")
write_dta(beta1,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/1_yr_lag_gross_beta1.dta")
write_dta(beta2,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/1_yr_lag_gross_beta2.dta")
write_dta(beta3,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/1_yr_lag_gross_beta3.dta")
write_dta(beta4,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/1_yr_lag_gross_beta4.dta")
write_dta(R2,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/1_yr_lag_gross_R2.dta")




#cal annual 3/5 year lagged alpha t alpha

ux<-unique(dat$a1)
alpha<-data.frame(matrix(nrow=length(ux),ncol=33))
alpha[,1]<-ux
t_alpha<-data.frame(matrix(nrow=length(ux),ncol=33))
t_alpha[,1]<-ux
R2<-data.frame(matrix(nrow=length(ux),ncol=33))
R2[,1]<-ux

beta1<-data.frame(matrix(nrow=length(ux),ncol=33))
beta1[,1]<-ux
beta2<-data.frame(matrix(nrow=length(ux),ncol=33))
beta2[,1]<-ux
beta3<-data.frame(matrix(nrow=length(ux),ncol=33))
beta3[,1]<-ux
beta4<-data.frame(matrix(nrow=length(ux),ncol=33))
beta4[,1]<-ux

y<-unique(year(dat$caldt))
y<-as.character(y)
a<-array(dim=33)
a[1]<-"Fund"
a[2:33]<-y
for (b in 2:33)
{
  a[b]<-paste0("y",a[b])
}

colnames(alpha)<-a
colnames(t_alpha)<-a
colnames(beta1)<-a
colnames(beta2)<-a
colnames(beta3)<-a
colnames(beta4)<-a
colnames(R2)<-a


for(i in 1:length(ux))
{
  dat1<-dat[dat$a1==ux[i],]
  
  if(substr(dat1$style[1],1,1)=="L")
  {
    if(substr(dat1$style[1], regexpr(" ", dat1$style) + 1, regexpr(" ", dat1$style) + 1)=="G")
    {
      bm<-"lcg"
    }
    if(substr(dat1$style[1], regexpr(" ", dat1$style) + 1, regexpr(" ", dat1$style) + 1)=="B")
    {
      bm<-"lcb"
    }
    else
    {
      bm<-"lcv"
    }
  }
  if(substr(dat1$style[1],1,1)=="M")
  {
    if(substr(dat1$style[1], regexpr(" ", dat1$style) + 1, regexpr(" ", dat1$style) + 1)=="G")
    {
      bm<-"mcg"
    }
    if(substr(dat1$style[1], regexpr(" ", dat1$style) + 1, regexpr(" ", dat1$style) + 1)=="B")
    {
      bm<-"mcb"
    }
    else
    {
      bm<-"mcv"
    }
  }
  if(substr(dat1$style[1],1,1)=="S")
  {
    if(substr(dat1$style[1], regexpr(" ", dat1$style) + 1, regexpr(" ", dat1$style) + 1)=="G")
    {
      bm<-"scg"
    }
    if(substr(dat1$style[1], regexpr(" ", dat1$style) + 1, regexpr(" ", dat1$style) + 1)=="B")
    {
      bm<-"scb"
    }
    else
    {
      bm<-"scv"
    }
  }
  
  dat1$bm<-dat1[[bm]]
  s<-1
  e<-3
  y<-unique(dat1$y)

    while(e<=length(y))
    {
      dat2<-dat1[dat1$y>=y[s] & dat1$y<=y[e],]
      reg<-lm(RF_sum_wt_gross_ret~bm+SMB+HML+MOM, data = dat2)
      c<-match(y[e],as.numeric(substr(a,2,5)))
      alpha[i,c+1]<-summary(reg)$coefficients[1,1]
      t_alpha[i,c+1]<-summary(reg)$coefficients[1,3]
      beta1[i,c+1]<-summary(reg)$coefficients[2,1]
      beta2[i,c+1]<-summary(reg)$coefficients[3,1]
      beta3[i,c+1]<-summary(reg)$coefficients[4,1]
      beta4[i,c+1]<-summary(reg)$coefficients[5,1]
      R2[i,c+1]<-summary(reg)$r.squared
      s<-s+1
      e<-e+1
    }
}

write_dta(alpha,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/3_yr_lag_gross_alpha_st.dta")
write_dta(t_alpha,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/3_yr_lag_gross_t_alpha_st.dta")
write_dta(beta1,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/3_yr_lag_gross_beta1_st.dta")
write_dta(beta2,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/3_yr_lag_gross_beta2_st.dta")
write_dta(beta3,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/3_yr_lag_gross_beta3_st.dta")
write_dta(beta4,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/3_yr_lag_gross_beta4_st.dta")
write_dta(R2,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/3_yr_lag_gross_R2_st.dta")



#Fund flow volatility
library(haven)
library(dplyr)
dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/Net_flow.dta")
ux<-unique(dat$a1)

dat_f<-data.frame(matrix(nrow=0,ncol=0))
for(i in 1:length(ux))
{
  dat1<-dat[dat$a1==ux[i],]
  dat1$flow_vol<-NA
  s<-1
  e<-12
  time<-sort(unique(dat1$caldt))
    while(e<=length(time))
    {
      dat2<-dat1[dat1$caldt>=time[s] & dat1$caldt<=time[e],]
      dat2<-dat2[is.na(dat2$net_flow)==FALSE,]
      m<-mean(dat2$net_flow)
      a<-(sum((dat2$net_flow-m)^2)/11)^(1/2)
      dat1$flow_vol[e]<-a
      s<-s+1
      e<-e+1
    }
  dat_f<-rbind(dat_f,dat1)
}
write_dta(dat_f,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/flow.dta")

#tracking error, information ratio, sharpe and sortino ratio
library(haven)
library(dplyr)
dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/Research_Data/Clean data/crsp_ms_4_1.dta")
ux<-unique(dat$a1)

dat_f<-data.frame(matrix(nrow=0,ncol=0))
for(i in 1:length(ux))
{
  dat1<-dat[dat$a1==ux[i],]
  dat1$tracking_error<-NA
  dat1$info_ratio<-NA
  dat1$sharpe_ratio<-NA
  dat1$sortino_ratio<-NA
  s<-1
  e<-12
  time<-sort(unique(dat1$caldt))
  while(e<=length(time))
  {
    dat2<-dat1[dat1$caldt>=time[s] & dat1$caldt<=time[e],]
    m<-mean(dat2$sum_wt_net_ret-((dat2$MktRF)/100))
    dat1$tracking_error[e]<-((1/11)*sum(((dat2$sum_wt_net_ret-(dat2$MktRF/100))-m)^2))^(1/2)
    dat1$info_ratio[e]<-m/dat1$tracking_error[e]
    sd<-sqrt(mean((dat2$RF_sum_wt_net_ret - mean(dat2$RF_sum_wt_net_ret))^2))
    dat1$sharpe_ratio[e]<-(mean(dat2$RF_sum_wt_net_ret - mean(dat2$RF_sum_wt_net_ret)))/sd
    r<-dat2[dat2$RF_sum_wt_net_ret<0,]$RF_sum_wt_net_ret
    sd1<-sqrt(mean((r- mean(r))^2))
    dat1$sortino_ratio[e]<-(mean(dat2$RF_sum_wt_net_ret - mean(dat2$RF_sum_wt_net_ret)))/sd1
    s<-s+1
    e<-e+1
  }
  dat_f<-rbind(dat_f,dat1)
}
write_dta(dat_f,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/ratios.dta")


#Fund mtna volatility
library(haven)
library(dplyr)
dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/tna_exp.dta")
ux<-unique(dat$a1)

dat_f<-data.frame(matrix(nrow=0,ncol=0))
for(i in 1:length(ux))
{
  dat1<-dat[dat$a1==ux[i],]
  dat1$mtna_vol<-NA
  s<-1
  e<-12
  time<-sort(unique(dat1$caldt))
  while(e<=length(time))
  {
    dat2<-dat1[dat1$caldt>=time[s] & dat1$caldt<=time[e],]
    dat2<-dat2[is.na(dat2$l_tna)==FALSE,]
    m<-mean(dat2$l_tna)
    a<-(sum((dat2$l_tna-m)^2)/11)^(1/2)
    dat1$mtna_vol[e]<-a
    s<-s+1
    e<-e+1
  }
  dat_f<-rbind(dat_f,dat1)
}
write_dta(dat_f,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/tna_exp_vol.dta")

#Fund mret volatility
library(haven)
library(dplyr)
dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/lag_ret.dta")
ux<-unique(dat$a1)

dat_f<-data.frame(matrix(nrow=0,ncol=0))
for(i in 1:length(ux))
{
  dat1<-dat[dat$a1==ux[i],]
  dat1$ret_vol<-NA
  s<-1
  e<-12
  time<-sort(unique(dat1$caldt))
  while(e<=length(time))
  {
    dat2<-dat1[dat1$caldt>=time[s] & dat1$caldt<=time[e],]
    dat2<-dat2[is.na(dat2$sum_wt_net_ret)==FALSE,]
    m<-mean(dat2$sum_wt_net_ret)
    a<-(sum((dat2$sum_wt_net_ret-m)^2)/11)^(1/2)
    dat1$ret_vol[e]<-a
    s<-s+1
    e<-e+1
  }
  dat_f<-rbind(dat_f,dat1)
}
write_dta(dat_f,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/ret_vol.dta")

