library(haven)
library(dplyr)
library(lubridate)
dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Data Cleaning/THOMPSON_STOCK_HOLDING_CRSP/us_thompson_crsp_a1.dta")
dat<- read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Data Cleaning/THOMPSON_STOCK_HOLDING_CRSP/thompson_crsp_a1.dta")
dat<-dat[dat$stkname!="",]
ux<-unique(dat$fundno)
mat<-data.frame(matrix(nrow=0,ncol=4))

bm<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Data Cleaning/BM/spx_all_1990_2021.dta")
bm<-bm[!is.na(bm$MarketCap)==TRUE,]
bm<-bm[!is.na(bm$Price)==TRUE,]
bm$s<-bm$Price*bm$MarketCap
bm<- bm %>%
  group_by(y) %>%
  mutate(ss=sum(s))

bm<- bm %>%
  group_by(y) %>%
  mutate(wt=s/ss)

bm$tick<-substr(bm$Ticker,1,nchar(bm$Ticker)-10)

for (i in 1:length(ux))
{
dat1<-dat[dat$fundno==ux[i],]
dat1$year<-year(dat1$fdate)
y<-unique(dat1$year)
dat_f<-data.frame(matrix(nrow=0,ncol=4))
r<-0
for (j in 1:length(y))
{
  bm1<-bm[bm$y==y[j],]
  bm1<-bm1 %>%
    distinct(Name, .keep_all = TRUE)
  
  dat2<-dat1[dat1$year==y[j],]
  m<-unique(month(dat2$fdate))
  dat3<-dat2[dat2$year==y[j] & month(dat2$fdate)==m[length(m)],]
  if(length(dat3[is.na(dat3$prc)==TRUE,]$stkname)!=0)
  {
    df<-dat3[is.na(dat3$prc)==TRUE,]
    for(n in 1:nrow(df))
    {
      if(length(which(df$stkname[n]==bm1$Name))==0)
      {
        next
      }
      else
      {
        dat3[dat3$stkname==df$stkname[n],]$prc<-bm$Price[which(df$stkname[n]==bm1$Name)]
      }
    }
    
  }
  dat3<-dat3[!is.na(dat3$prc),]
  
  dat3$s<-dat3$shares*dat3$prc
  dat3$wt<-dat3$s/sum(dat3$s)
  
  dat3<- dat3 %>%
    distinct(stkname, .keep_all = TRUE)
  

  w<-0
  for(s in 1:nrow(dat3))
  {
    if(length(which(tolower(dat3$stkname[s])==tolower(bm1$Name)))==0)
    {
      if(length(which(dat3$ticker[s]==bm1$tick))==0)
      {
        next
      }
      else
      {
        w<-w+(dat3$wt[s]-bm1$wt[which(dat3$ticker[s]==bm1$tick)])^2
        
      }
    }
    if(length(which(tolower(dat3$stkname[s])==tolower(bm1$Name)))!=0)
    {
      w<-w+(dat3$wt[s]-bm1$wt[which(tolower(dat3$stkname[s])==tolower(bm1$Name))])^2
      
      
    }
  
  }
  
  dat_f[r+1,1]<-dat3$fundno[1]
  dat_f[r+1,2]<-dat3$a1[1]
  dat_f[r+1,3]<-dat3$year[1]
  dat_f[r+1,4]<-w
  r<-r+1
}
mat<-rbind(mat,dat_f)
}
colnames(mat)<-c("Fund_no","a1","year","deviation")
write_dta(mat,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/thompson.dta")

