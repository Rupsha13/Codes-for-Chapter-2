dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Data Cleaning/CRSP_THOMPSON_MS/MS_VAR/Hist_Style_90-21.dta")
library(haven)
library(dplyr)
library(lubridate)
dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/style.dta")

ux<-unique(dat$a1)


mat<-data.frame(matrix(nrow=length(ux),ncol=33))
mat[,1]<-ux
mat1<-data.frame(matrix(nrow=length(ux),ncol=33))
mat1[,1]<-ux

y<-sort(unique(dat$y))
y<-as.character(y)
a<-array(dim=33)
a[1]<-"Fund"
a[2:33]<-y
for (b in 2:33)
{
  a[b]<-paste0("y",a[b])
}

colnames(mat)<-a
colnames(mat1)<-a

year<-as.numeric(y)

for (i in 1:length(year))
{
  dat1 <- dat %>% filter(y == year[i])
  dat1<-dat1 %>% filter(hist_style!=".")
  dat1<-dat1 %>% filter(hist_style!="")
  u1<-unique(dat1$a1)
  
  for (f in 1:length(u1))
  {
    d<-dat1 %>%
      group_by(a1) %>%
      summarise(n_distinct(hist_style))
    
  }
  
  mat[match(d$a1,mat$Fund),i+1]<-d$`n_distinct(hist_style)`
  
}



mat1[,]<-0
mat1[,2]<-mat[,2]
mat1[] <- lapply(mat1, as.numeric)
mat[] <- lapply(mat, as.numeric)
for (i in 3:33)
{
  mat1[,i]<-ifelse(is.na(mat1[,i-1]),0,mat1[,i-1])+ifelse(is.na(mat[,i]),0,mat[,i])
}


write_dta(mat,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/1_yr_lag_style_shift.dta")
data<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Independant Variables/1_yr_lag_t_alpha_st.dta")
colnames(data)<-a

