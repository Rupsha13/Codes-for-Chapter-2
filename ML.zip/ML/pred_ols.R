library(haven)
library(dplyr)
library(lubridate)
dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/Research_Data/Clean data/crsp_ms_4_1.dta")
ols<-read.csv("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/ols_predictions.csv")
rf<-read.csv("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/rf_predictions.csv")
xg<-read.csv("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/xgb_predictions.csv")

dat_p<-rf
dat_p$year=year(rf$caldt)
dat_p<-dat_p %>%
  group_by(a1, year) %>%
  summarise(pred=12*mean(predicted_value))
rf<-dat_p

#style
dat_p<-rename(dat_p,"y"="year")

dat_m<-merge(dat_p,dat, by=c("a1","y")) 

mat1<-data.frame(matrix(nrow=0,ncol=0))

style<-c("Large Growth","Large Blend","Large Value","Mid Growth","Mid Blend","Mid Value","Small Growth","Small Blend","Small Value")

for (s in 1:9)
{
  mat<-dat_m[dat_m$style==style[s],]
  
  for (i in 1:length(yr))
  {
    df<-mat[mat$y==yr[i],]
    
    
    df$decile <- cut(df$pred, 
                     breaks = quantile(df$pred, probs = 0:10 / 10), 
                     include.lowest = TRUE, 
                     labels = 1:10)
    df<-df[order(df$decile),]
    mat1<-rbind(mat1,df)
  }
}
  
  
yr<-unique(dat$y) 
#no style

mat1<-data.frame(matrix(nrow=0,ncol=0))
for (i in 1:length(yr))
{
  df<-dat_p[dat_p$year==yr[i],]
  
  df$decile <- cut(df$pred, 
                   breaks = quantile(df$pred, probs = 0:10 / 10), 
                   include.lowest = TRUE, 
                   labels = FALSE)
  df<-df[order(df$decile),]
  #mat1<-rbind(mat1,df)

  for (d in 1:10)
  {
    u<-unique(df[df$decile==d,]$a1)
    mat<-dat %>%
      filter(a1 %in% u) 
    mat<-mat %>%
      filter(mat$y==yr[i])
    mat$dec<-d
   mat1<-rbind(mat1,mat)
  }
}

ols_pred<-mat1
rf_pred<-mat1
xg<-mat1

write_dta(rf_pred,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/rf_sorted.dta")

ols<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/ols.dta")
rf<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/rf.dta")
xg<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/Sorted/xg.dta")



dat<-ols_pred %>%
  filter(dec==10)
#ols_st<-dat

dat1<-xg %>%
  filter (dec==10)
#xg_st<-dat1

dat2<-rf_pred %>%
  filter (dec==10)



dat<-dat %>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))


dat1<-dat1 %>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))


dat2<-dat2 %>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))

BM<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/Research_Data/Clean data/BM_90-21.dta")
dat<-merge(dat,BM, by="caldt")
dat1<-merge(dat1,BM, by="caldt")
dat2<-merge(dat2,BM, by="caldt")

reg<-lm(dat$mean_net_ret~dat$MktRF+dat$SMB+dat$HML+dat$MOM)
beta1<-summary(reg)$coefficients[2,1]
beta2<-summary(reg)$coefficients[3,1]
beta3<-summary(reg)$coefficients[4,1]
beta4<-summary(reg)$coefficients[5,1]
dat$alpha<-dat$mean_net_ret-beta1*(dat$MktRF/100)-beta2*(dat$SMB/100)-beta3*(dat$HML/100)-beta4*(dat$MOM/100)
alpha<-summary(reg)$coefficients[1,1]


reg1<-lm(dat1$mean_net_ret~dat1$MktRF+dat1$SMB+dat1$HML+dat1$MOM)
beta1<-summary(reg1)$coefficients[2,1]
beta2<-summary(reg1)$coefficients[3,1]
beta3<-summary(reg1)$coefficients[4,1]
beta4<-summary(reg1)$coefficients[5,1]
dat1$alpha<-dat1$mean_net_ret-beta1*(dat1$MktRF/100)-beta2*(dat1$SMB/100)-beta3*(dat1$HML/100)-beta4*(dat1$MOM/100)
alpha1<-summary(reg1)$coefficients[1,1]

reg2<-lm(dat2$mean_net_ret~dat2$MktRF+dat2$SMB+dat2$HML+dat2$MOM)
beta1<-summary(reg2)$coefficients[2,1]
beta2<-summary(reg2)$coefficients[3,1]
beta3<-summary(reg2)$coefficients[4,1]
beta4<-summary(reg2)$coefficients[5,1]
dat2$alpha<-dat2$mean_net_ret-beta1*(dat2$MktRF/100)-beta2*(dat2$SMB/100)-beta3*(dat2$HML/100)-beta4*(dat2$MOM/100)
alpha2<-summary(reg2)$coefficients[1,1]


cum_alpha_ols <- cumprod(1 + dat$alpha)-1
cum_alpha_xg <- cumprod(1 + dat1$alpha)-1
cum_alpha_rf <- cumprod(1 + dat2$alpha)-1

plot(cum_alpha_ols, type = "l", col = "black",
     lwd = 3, lty = 1, ylim=c(-0.5,10),
     ylab = "Cumulative Alpha", xlab = "Time",
     main = "Cumulative Alpha Growth of Top Decile")

lines(cum_alpha_xg, col = "green", lwd = 2, lty = 2)

lines(cum_alpha_rf, col = "blue", lwd = 2, lty = 4)

# Add legend
legend("topleft", legend = c("OLS", "XGB", "RF"),
       col = c("blue", "green","red"), lwd = c(3, 2), lty = c(2, 1))



#draw top decile of nine styles

ols<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/mk_w_st/Sorted/ols.dta")
xg<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/Sorted/xg.dta")


ols<-ols %>%
  filter(dec==10)

xg<-xg %>%
  filter(decile==10)

ols<-ols %>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))

xg<-xg %>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))

BM<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/Research_Data/Clean data/BM_90-21.dta")
ols<-merge(ols,BM, by="caldt")
xg<-merge(xg,BM, by="caldt")

dat1<-ols
reg<-lm(dat1$mean_net_ret~dat1$MktRF+dat1$SMB+dat1$HML+dat1$MOM)
beta1<-summary(reg)$coefficients[2,1]
beta2<-summary(reg)$coefficients[3,1]
beta3<-summary(reg)$coefficients[4,1]
beta4<-summary(reg)$coefficients[5,1]
dat1$alpha<-dat1$mean_net_ret-beta1*(dat1$MktRF/100)-beta2*(dat1$SMB/100)-beta3*(dat1$HML/100)-beta4*(dat1$MOM/100)
cum_alpha_ols <- cumprod(1 + dat1$alpha)-1

rm(dat1)
dat1<-xg
reg<-lm(dat1$mean_net_ret~dat1$MktRF+dat1$SMB+dat1$HML+dat1$MOM)
beta1<-summary(reg)$coefficients[2,1]
beta2<-summary(reg)$coefficients[3,1]
beta3<-summary(reg)$coefficients[4,1]
beta4<-summary(reg)$coefficients[5,1]
dat1$alpha<-dat1$mean_net_ret-beta1*(dat1$MktRF/100)-beta2*(dat1$SMB/100)-beta3*(dat1$HML/100)-beta4*(dat1$MOM/100)
cum_alpha_xg <- cumprod(1 + dat1$alpha)-1
rm(dat1)

plot(cum_alpha_xg, type = "l", col = "black", ylim=c(-0.05,30),
     lwd = 3, lty = 1,
     ylab = "Cumulative Alpha", xlab = "Time",
     main = "Cumulative Alpha Growth of Top Decile")

lines(cum_alpha_xg, col = "black", lwd = 2, lty = 2)


xg_st<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/Sorted/xg.dta")
s<-c("Large Growth","Large Blend","Large Value","Mid Growth","Mid Blend","Mid Value","Small Growth","Small Blend","Small Value")
colors <- c("red", "blue", "green", "orange", 
            "purple", "brown", "pink", "cyan", "gold")

xg_st_m<-xg_st %>%
  filter(decile==10)

xg_st<-xg %>%
  filter(style=="Small Growth")

xg_st<-xg_st %>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))
xg_st<-merge(xg_st,BM, by="caldt")


dat1<-xg_st
reg<-lm(dat1$mean_net_ret~dat1$scg+dat1$SMB+dat1$HML+dat1$MOM)
beta1<-summary(reg)$coefficients[2,1]
beta2<-summary(reg)$coefficients[3,1]
beta3<-summary(reg)$coefficients[4,1]
beta4<-summary(reg)$coefficients[5,1]
dat1$alpha<-dat1$mean_net_ret-beta1*(dat1$scg/100)-beta2*(dat1$SMB/100)-beta3*(dat1$HML/100)-beta4*(dat1$MOM/100)
cum_alpha_xg_st <- cumprod(1 + dat1$alpha)-1


lines(cum_alpha_xg_st, col = 'red', lwd = 2, lty = 3)






#feature importance
ols<-read.csv("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New Predictions/ols_feature_importance.csv")
rf<-read.csv("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New Predictions/w_lags_mk_w_st/rf_feature_importance.csv")
xg<-read.csv("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/xgb_feature_importance.csv")
dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/Research_Data/Clean data/crsp_ms_4_1.dta")

st<-c("Large Growth","Large Blend","Large Value","Mid Growth","Mid Blend","Mid Value","Small Growth","Small Blend","Small Value")

dat<- ols %>%
  group_by(predictor) %>%
  summarise(imp=mean(importance))

dat_s <- dat %>% select(a1, style, y)
rf<-merge(rf,dat_s, by=c("a1","y"))

for (s in 1:9)
{
  dat1<-rf[rf$]
}






dat2<- xg %>%
  group_by(predictor) %>%
  summarise(imp=mean(importance))


library(ggplot2)

ggplot(dat2, aes(x = reorder(predictor, imp), y = imp)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +  # optional: flips the bars for readability
  labs(title = "Importance of Predictors for Boosting",
       x = "Predictor",
       y = "Importance") +
  theme_minimal()



write_dta (dat,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/ols_features.dta")
write_dta (dat1,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/rf_features.dta")
write_dta (dat2,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/xg_features.dta")



##########################

xg_w_st<-xg_w_st%>%
  filter(dec==10)

xg_w_st<-xg_w_st%>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))

xg_wo_st<-xg_wo_st%>%
  filter(dec==10)

xg_wo_st<-xg_wo_st%>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))



BM<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/Research_Data/Clean data/BM_90-21.dta")
xg_w_st<-merge(xg_w_st,BM, by="caldt")
xg_wo_st<-merge(xg_wo_st,BM, by="caldt")

summary(lm(mean_net_ret~MktRF+SMB+HML+MOM,data = xg_w_st))
summary(lm(mean_net_ret~MktRF+SMB+HML+MOM,data = xg_wo_st))


ols<-read.csv("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/ols_fund_year_predictions.csv")
dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/Research_Data/Clean data/crsp_ms_4_1.dta")


yr<-sort(unique(ols$y))
dat_p<-ols
mat1<-data.frame(matrix(nrow=0,ncol=0))
for (i in 1:length(yr))
{
  df<-dat_p[dat_p$y==yr[i],]
  
  df$decile <- cut(df$predicted, 
                   breaks = quantile(df$predicted, probs = 0:10 / 10), 
                   include.lowest = TRUE, 
                   labels = 1:10)
  df<-df[order(df$decile),]
  for (d in 1:10)
  {
    u<-unique(df[df$decile==d,]$a1)
    mat<-dat %>%
      filter(a1 %in% u) 
    mat<-mat %>%
      filter(mat$y==yr[i])
    mat$dec<-d
    mat1<-rbind(mat1,mat)
  }
}
write_dta(mat1,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/ols.dta")
rf<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/rf_sorted_10.dta")
ols<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/ols_sorted_10.dta")

rf<-rf[rf$dec==10,]
ols<-ols[ols$dec==10,]


rf<-rf%>%
  group_by(caldt) %>%
  mutate(s=sum(s_mtna))

rf<-rf %>%
  mutate(w=s_mtna/s) %>%
  mutate(wt_net_ret=sum_wt_net_ret*w)%>%
  mutate(sum_net_ret=sum(wt_net_ret)) %>%
  mutate(net_ret=sum_net_ret-(rf/100))

ols<-ols %>%
  group_by(caldt) %>%
  mutate(s=sum(s_mtna))

ols<-ols %>%
  mutate(w=s_mtna/s) %>%
  mutate(wt_net_ret=sum_wt_net_ret*w)%>%
  mutate(sum_net_ret=sum(wt_net_ret)) %>%
  mutate(net_ret=sum_net_ret-(rf/100))
  

BM<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/Research_Data/Clean data/BM_90-21.dta")
ols<-merge(ols,BM, by="caldt")
rf<-merge(rf,BM, by="caldt")

dat1<-rf
dat1<-dat1 %>%
  select(caldt,net_ret,MktRF,SMB,HML,MOM) %>%
  distinct()

reg<-lm(dat1$net_ret~dat1$MktRF+dat1$SMB+dat1$HML+dat1$MOM)
beta1<-summary(reg)$coefficients[2,1]
beta2<-summary(reg)$coefficients[3,1]
beta3<-summary(reg)$coefficients[4,1]
beta4<-summary(reg)$coefficients[5,1]
dat1$alpha<-dat1$net_ret-beta1*(dat1$MktRF/100)-beta2*(dat1$SMB/100)-beta3*(dat1$HML/100)-beta4*(dat1$MOM/100)
alpha_ols <- dat1 %>%
  select(caldt,alpha) %>%
  distinct()
alpha_rf <- dat1 %>%
  select(caldt,alpha) %>%
  distinct()
  
cum_alpha_ols <- cumprod(1 + alpha_ols$alpha)-1
plot(cum_alpha_ols, type = "l", col = "black",ylim=c(-0.1,7),
     lwd = 3, lty = 1,
     ylab = "Cumulative Alpha", xlab = "Time",
     main = "Cumulative Alpha Growth of Top Decile")

cum_alpha_rf <- cumprod(1 + alpha_rf$alpha)-1
lines(cum_alpha_rf, col = "red", lwd = 2, lty = 2)
legend("topleft", legend = c("OLS", "RF"),
       col = c("black","red"), lwd = c(3, 2), lty = c(1, 2))


Final_net_mk_no_na_2 <- Final_net_mk_no_na_2[, !names(Final_net_mk_no_na_2) %in% c("y", "a1", "ann_net_alpha")]

cov_matrix <- cov(Final_net_mk_no_na_2)

# Print the covariance matrix
print(cov_matrix)

# Compute covariance matrix, ignoring NA values
cov_matrix <- cov(Final_net_mk_no_na_2, use = "complete.obs")

# View the covariance matrix
print(cov_matrix)


df<-dat[dat$a1==146,]
df1<-df[df$y>=1990 & df$y<1995,]
reg<-lm(RF_sum_wt_net_ret~MktRF+HML+SMB+MOM, dat=df1)
beta1<-summary(reg)$coefficients[2,1]
beta2<-summary(reg)$coefficients[3,1]
beta3<-summary(reg)$coefficients[4,1]
beta4<-summary(reg)$coefficients[5,1]
df$alpha<-df$RF_sum_wt_net_ret-beta1*(df$MktRF/100)-beta2*(df$SMB/100)-beta3*(df$HML/100)-beta4*(df$MOM/100)
mean(df[df$y==1995,]$alpha)*12
