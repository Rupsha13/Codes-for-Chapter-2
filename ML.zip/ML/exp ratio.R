dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Results/Exp ratio/rf_mk_w_st_exp.dta")



# Boxplot
colors <- c("red", "blue", "green", "orange", "purple", "cyan", "magenta", "yellow", "gray", "brown")

# Create the boxplot with fixed colors
boxplot(dat$exp_ratio ~ dec, data = dat,
        col = colors, las = 2,
        main = "Expense Ratios Across Fund Groups",
        xlab = "Group", ylab = "Expense Ratio")


stripchart(dat$exp_ratio ~ dec, data = dat,
           method = "jitter",    # spreads points to avoid overlap
           pch = 16,             # solid dots
           col = colors,         # color of points
           vertical = TRUE,      # vertical layout
           las = 2,              # rotate group labels
           main = "Expense Ratios by Deciles (RF)",
           xlab = "Deciles", ylab = "Expense Ratio")

dat10<-dat %>%
  filter(dec==1)

dat1<-dat10 %>%
  group_by(style) %>%
  summarise(exp=mean(comp, na.rm=TRUE))


dat_b<-dat1[dat1$dec==1,]
dat_b<-dat_b %>%
  group_by(caldt) %>%
  summarise(comp=mean(comp_m, na.rm=TRUE))

dat_m<-dat1[dat1$dec==5,]
dat_m<-dat_m %>%
  group_by(caldt) %>%
  summarise(comp=mean(comp_m, na.rm=TRUE))

dat_t<-dat1[dat1$dec==10,]
dat_t<-dat_t %>%
  group_by(caldt) %>%
  summarise(comp=mean(comp_m, na.rm=TRUE))

plot(dat_b$comp, type = "l", col = "black", ylim=c(0,30),
     lwd = 3, lty = 1,
     ylab = "Compensation", xlab = "Time",
     main = "Compensation by Deciles")

lines(dat_m$comp, col = "green", lwd = 2, lty = 1)

lines(dat_t$comp, col = "red", lwd = 2, lty = 1)

# Add legend
legend("topleft", legend = c("OLS", "XGB", "RF"),
       col = c("blue", "green","red"), lwd = c(3, 2), lty = c(2, 1))



library(ggplot2)

ggplot(dat, aes(x = dec, y = exp_ratio, fill = dec)) +
  geom_violin(trim = FALSE) +
  theme_minimal() +
  labs(title = "Expense Ratio Distribution by Deciles",
       x = "Deciles", y = "Expense Ratio") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

