ols<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/ols.dta")
nn<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/rnn.dta")
library(haven)
#persistence
library(dplyr)
library(lubridate)

df<-nn %>%
  filter(dec==10)

# Make sure 'date' is Date type and extract year
df <- df %>%
  mutate(date = as.Date(caldt),
         year = year(date))

# Create a summary with the latest return in each year per fund
latest_returns <- df %>%
  group_by(a1, y) %>%
  filter(date == max(caldt)) %>%
  ungroup()

# Initialize result storage
results <- data.frame(year = integer(), top_decile_retained = integer(), total_in_top = integer())
yr<-unique(df$year)

# Loop through 1990 to 2020 (we need year t and t+1)
for (y in 1:(length(yr)-1)) {
  # Year t deciles
  t_data <- latest_returns[latest_returns$year==yr[y],]
  t1_data <- latest_returns[latest_returns$year==yr[y+1],]
  
  if (nrow(t_data) == 0 | nrow(t1_data) == 0) next
  
  # Assign deciles in year t
  t_data <- t_data %>%
    mutate(decile_t = ntile(sum_wt_net_ret, 10))
  
  # Only take top decile funds from year t
  top_t_funds <- t_data %>%
    filter(decile_t == 10) %>%
    select(a1)
  
  # Assign deciles in year t+1
  t1_data <- t1_data %>%
    mutate(decile_t1 = ntile(sum_wt_net_ret, 10))
  
  # Merge and check how many top-t funds are still in top decile at t+1
  matched <- inner_join(top_t_funds, t1_data, by = "a1")
  top_decile_retained <- sum(matched$decile_t1 == 10, na.rm = TRUE)
  total_in_top <- nrow(top_t_funds)
  
  results <- rbind(results, data.frame(year = yr[y], 
                                       top_decile_retained = top_decile_retained, 
                                       total_in_top = total_in_top))
}

# Add share retained
results <- results %>%
  mutate(share_retained = top_decile_retained / total_in_top)

print(results)


#persistence over 1 quarter
df<-crsp_ms_5_skilled_unskilled
library(dplyr)
library(zoo)
library(data.table)

df<-df[df$skill_st==1,]
# Step 1: Convert date column to proper Date format
df <- df %>%
  mutate(Date = as.Date(caldt),
         Quarter = as.yearqtr(Date))

# Step 2: Calculate quarterly return for each fund
quarterly_returns <- df %>%
  group_by(a1, Quarter) %>%
  summarise(QuarterlyReturn = prod(1 + RF_sum_wt_gross_ret, na.rm = TRUE) - 1, .groups = "drop")

# Step 3: Assign quintiles within each quarter
quarterly_returns <- quarterly_returns %>%
  group_by(Quarter) %>%
  mutate(Quintile = ntile(QuarterlyReturn, 5)) %>%
  ungroup()

# Step 4: Create lagged and lead quintiles by fund
setDT(quarterly_returns)
quarterly_returns[, `:=`(
  Next_Quarter = shift(Quarter, type = "lead"),
  Next_Quintile = shift(Quintile, type = "lead")
), by = a1]

# Step 5: Filter for current and next quarter top quintile (quintile 5)
top_persistence <- quarterly_returns[
  Quintile == 5 & Next_Quintile == 5
]

# Step 6: Count number of funds that stayed in top quintile per quarter
result <- top_persistence[, .N, by = Quarter]
names(result)[2] <- "TopQuintilePersistingFunds"

result_st<-result
result_mk<-result

# Assuming you have:
# result_1q: contains TopQuintilePersisting_1Q for 1-quarter persistence
# result_2q: contains TopQuintilePersisting_2Q for 2-quarter persistence

# Add a label column to each
result_st$Type <- "Style BM"
result_mk$Type <- "Market BM"

# Rename persistence column to same name
setnames(result_st, "TopQuintilePersistingFunds", "Value")
setnames(result_mk, "TopQuintilePersistingFunds", "Value")

# Combine datasets
combined <- rbind(result_st[, .(Quarter, Value, Type)],
                  result_mk[, .(Quarter, Value, Type)])

# Plot
library(ggplot2)

ggplot(combined, aes(x = as.Date(Quarter), y = Value, color = Type)) +
  geom_line(size = 1.2) +
  geom_point(size = 2) +
  labs(
    title = "Top Quintile Fund Persistence Over Time",
    x = "Quarter",
    y = "Number of Funds Remaining in Top Quintile",
    color = "Un-skilled funds"
  ) +
  theme_minimal()


# View result
print(result)
write_dta(rseult,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/RESULTS/PERSISTENCE/Persistence_skill.dta")


library(ggplot2)

ggplot(result, aes(x = as.Date(Quarter), y = TopQuintilePersistingFunds)) +
  geom_line(color = "steelblue", size = 1.2) +
  geom_point(color = "darkblue", size = 2) +
  labs(
    title = "Top Quintile Fund Persistence Over Time",
    x = "Quarter",
    y = "Number of Funds Remaining in Top Quintile"
  ) +
  theme_minimal()


# Total number of top-quintile funds per quarter
total_top <- quarterly_returns[Quintile == 5, .N, by = Quarter]
setnames(total_top, "N", "TotalTopQuintile")

# Merge with persistence data
result <- merge(result, total_top, by = "Quarter")

# Calculate percentage
result[, Percentage := 100 * TopQuintilePersistingFunds / TotalTopQuintile]

ggplot(result, aes(x = as.Date(Quarter), y = Percentage)) +
  geom_line(color = "forestgreen", size = 1.2) +
  geom_point(color = "darkgreen", size = 2) +
  labs(
    title = "Percentage of Top Quintile Funds Remaining Next Quarter",
    x = "Quarter",
    y = "Persistence Rate (%)"
  ) +
  theme_minimal()


#perssitence over 2 quarters plus the current one

# 1. Assume df is already in panel format with Fund, Date, Return
df <- df %>%
  mutate(Date = as.Date(caldt),
         Quarter = as.yearqtr(Date))

# 2. Compute quarterly returns
quarterly_returns <- df %>%
  group_by(a1, Quarter) %>%
  summarise(QuarterlyReturn = prod(1 + RF_sum_wt_gross_ret, na.rm = TRUE) - 1, .groups = "drop")

# 3. Assign quintiles
quarterly_returns <- quarterly_returns %>%
  group_by(Quarter) %>%
  mutate(Quintile = ntile(QuarterlyReturn, 5)) %>%
  ungroup()

# 4. Add next two quarters' quintiles
setDT(quarterly_returns)
quarterly_returns[, `:=`(
  Q_next_1 = shift(Quintile, type = "lead", n = 1),
  Q_next_2 = shift(Quintile, type = "lead", n = 2),
  Qtr_next_1 = shift(Quarter, type = "lead", n = 1),
  Qtr_next_2 = shift(Quarter, type = "lead", n = 2)
), by = a1]

# 5. Filter: top quintile for 3 consecutive quarters
persistent_2q <- quarterly_returns[
  Quintile == 5 & Q_next_1 == 5 & Q_next_2 == 5
]

# 6. Count how many stayed in top quintile for 3 quarters
result_2q <- persistent_2q[, .N, by = Quarter]
names(result_2q)[2] <- "TopQuintile_2Q_Persisting"

# Optional: Add percentage of eligible funds
top_q_each_qtr <- quarterly_returns[Quintile == 5, .N, by = Quarter]
setnames(top_q_each_qtr, "N", "TotalTopQuintile")

result_2q <- merge(result_2q, top_q_each_qtr, by = "Quarter")
result_2q[, Percentage := 100 * TopQuintile_2Q_Persisting / TotalTopQuintile]

# 7. Plot
library(ggplot2)
ggplot(result_2q, aes(x = as.Date(Quarter), y = Percentage)) +
  geom_line(color = "tomato", size = 1.2) +
  geom_point(color = "red4", size = 2) +
  labs(
    title = "Persistence of Top Quintile Funds Over Two Consecutive Quarters",
    x = "Quarter (Start)",
    y = "Percentage Remaining Top Quintile (Next 2 Quarters)"
  ) +
  theme_minimal()
write_dta(result_2q,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/RESULTS/PERSISTENCE/Persistence_2Q.dta")


