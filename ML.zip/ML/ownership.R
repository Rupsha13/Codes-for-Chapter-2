library(haven)
library(dplyr)

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Data Cleaning/MS_Dead_ownership.dta")

df <- dat %>%
  mutate(o_0 = if_else(ownership_code == 0, 1, 0), o_1 = if_else(ownership_code == 1, 1, 0),o_2 = if_else(ownership_code == 2, 1, 0),o_3 = if_else(ownership_code == 3, 1, 0),o_4 = if_else(ownership_code == 4, 1, 0),o_5 = if_else(ownership_code == 5, 1, 0),o_6 = if_else(ownership_code == 6, 1, 0),o_7 = if_else(ownership_code == 7,1,0))

df<-df %>%
  distinct(fundid,managerid, .keep_all = TRUE)

df<- df %>%
  group_by(fundid) %>%
  mutate(s_1=sum(o_1)/no_of_managers,s_2=sum(o_2)/no_of_managers,s_3=sum(o_3)/no_of_managers,s_4=sum(o_4)/no_of_managers,s_5=sum(o_5)/no_of_managers,s_6=sum(o_6)/no_of_managers,s_7=sum(o_7)/no_of_managers)

df<-df %>%
  distinct(fundid, .keep_all = TRUE)

write_dta(df,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Data Cleaning/MS_Dead_ownership.dta")
