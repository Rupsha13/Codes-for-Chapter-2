ols<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/w_lags_mk_w_st/Sorted/ols.dta")
rf<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/w_lags_mk_w_st/Sorted/rf.dta")
xg<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/ML/Predictions/New predictions/w_lags_mk_w_st/Sorted/xg.dta")

#agg alphas-one portfolio per year

dat<-ols %>%
  filter(dec==10)

dat1<-xg %>%
  filter (dec==10)

dat2<-rf %>%
  filter (dec==10)

dat<-dat %>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))



dat1<-dat1 %>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))


dat2<-dat2 %>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))

yr<-unique(year(dat$caldt))

BM<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/Research_Data/Clean data/BM_90-21.dta")
dat<-merge(dat,BM, by="caldt")
dat1<-merge(dat1,BM, by="caldt")
dat2<-merge(dat2,BM, by="caldt")

alpha<-data.frame(matrix(nrow=length(yr),ncol=4))
alpha[,1]<-yr
colnames(alpha)<-c("year","ols","rf","xgb")

for (y in 1:length(yr))
{
  df<-dat2[year(dat2$caldt)==yr[y],]
  alpha[y,3]<-summary(lm(mean_net_ret~MktRF+SMB+HML+MOM, data=df))$coefficients[1,1]
}

plot(alpha$ols, type = "l", col = "black",
     lwd = 3, lty = 1,
     ylab = "Alpha", xlab = "Time",
     main = "Alpha across time period 2005 to 2021")

lines(alpha$xgb, col = "blue", lwd = 2, lty = 2)

lines(alpha$rf, col = "red", lwd = 2, lty = 4)

# Add legend
legend("topleft", legend = c("OLS", "XGB", "RF"),
       col = c("black", "green","red"), lwd = c(3, 2), lty = c(2, 1))


mean(alpha$ols)
mean(alpha$xgb)
mean(alpha$rf)


reg<-lm(dat$mean_net_ret~dat$MktRF+dat$SMB+dat$HML+dat$MOM)
beta1<-summary(reg)$coefficients[2,1]
beta2<-summary(reg)$coefficients[3,1]
beta3<-summary(reg)$coefficients[4,1]
beta4<-summary(reg)$coefficients[5,1]
dat$alpha<-dat$mean_net_ret-beta1*(dat$MktRF/100)-beta2*(dat$SMB/100)-beta3*(dat$HML/100)-beta4*(dat$MOM/100)


reg1<-lm(dat1$mean_net_ret~dat1$MktRF+dat1$SMB+dat1$HML+dat1$MOM)
beta1<-summary(reg1)$coefficients[2,1]
beta2<-summary(reg1)$coefficients[3,1]
beta3<-summary(reg1)$coefficients[4,1]
beta4<-summary(reg1)$coefficients[5,1]
dat1$alpha<-dat1$mean_net_ret-beta1*(dat1$MktRF/100)-beta2*(dat1$SMB/100)-beta3*(dat1$HML/100)-beta4*(dat1$MOM/100)


reg2<-lm(dat2$mean_net_ret~dat2$MktRF+dat2$SMB+dat2$HML+dat2$MOM)
beta1<-summary(reg2)$coefficients[2,1]
beta2<-summary(reg2)$coefficients[3,1]
beta3<-summary(reg2)$coefficients[4,1]
beta4<-summary(reg2)$coefficients[5,1]
dat2$alpha<-dat2$mean_net_ret-beta1*(dat2$MktRF/100)-beta2*(dat2$SMB/100)-beta3*(dat2$HML/100)-beta4*(dat2$MOM/100)



cum_alpha_ols <- cumprod(1 + dat$alpha)-1
cum_alpha_xg <- cumprod(1 + dat1$alpha)-1
cum_alpha_rf <- cumprod(1 + dat2$alpha)-1


plot(cum_alpha_ols, type = "l", col = "black",ylim=c(-0.02,35),
     lwd = 3, lty = 1,
     ylab = "Cumulative Alpha", xlab = "Time",
     main = "Cumulative Alpha Growth of Top Decile")

lines(cum_alpha_xg, col = "blue", lwd = 2, lty = 2)

lines(cum_alpha_rf, col = "red", lwd = 2, lty = 4)

# Add legend
legend("topleft", legend = c("OLS", "XGB", "RF"),
       col = c("black", "blue","red"), lwd = c(3, 2), lty = c(2, 1))


###############
#draw style alphas
dat1_st<-xg %>%
  filter (decile==10)

st<-c("Large Growth","Large Blend","Large Value","Mid Growth","Mid Blend","Mid Value","Small Growth","Small Blend","Small Value")

s=7
xg<-dat1 %>%
  filter(style==st[s])
xg_st<- dat1_st %>%
  filter(style==st[s])

xg<-xg %>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))

xg_st<-xg_st %>%
  group_by(caldt) %>%
  summarise(mean_net_ret=mean(RF_sum_wt_net_ret))

BM<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/Research_Data/Clean data/BM_90-21.dta")
xg<-merge(xg,BM, by="caldt")
xg_st<-merge(xg_st,BM, by="caldt")



reg<-lm(mean_net_ret~MktRF+SMB+HML+MOM, data=xg)
beta1<-summary(reg)$coefficients[2,1]
beta2<-summary(reg)$coefficients[3,1]
beta3<-summary(reg)$coefficients[4,1]
beta4<-summary(reg)$coefficients[5,1]
xg$alpha<-xg$mean_net_ret-beta1*(xg$MktRF/100)-beta2*(xg$SMB/100)-beta3*(xg$HML/100)-beta4*(xg$MOM/100)
cum_alpha<-cumprod(1 + xg$alpha)-1

reg1<-lm(mean_net_ret~scg+SMB+HML+MOM, data=xg)
beta1<-summary(reg1)$coefficients[2,1]
beta2<-summary(reg1)$coefficients[3,1]
beta3<-summary(reg1)$coefficients[4,1]
beta4<-summary(reg1)$coefficients[5,1]
xg_st$alpha<-xg_st$mean_net_ret-beta1*(xg_st$scg/100)-beta2*(xg_st$SMB/100)-beta3*(xg_st$HML/100)-beta4*(xg_st$MOM/100)
cum_alpha_st<-cumprod(1 + xg_st$alpha)-1

plot(cum_alpha, type="l")
lines(cum_alpha_st,col='red')
